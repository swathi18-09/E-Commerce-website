function login() {
    var username = document.getElementById("loginUsername").value;
    var password = document.getElementById("loginPassword").value;

    // Here you would perform actual login validation
    if (username === "admin" && password === "password") {
        alert("Login successful!");
    } else {
        alert("Invalid username or password!");
    }
}

function signup() {
    var name = document.getElementById("signupName").value;
    var username = document.getElementById("signupUsername").value;
    var password = document.getElementById("signupPassword").value;

    // Here you would perform signup action, like sending data to server for registration
    alert("Signup successful! Name: " + name + ", Username: " + username + ", Password: " + password);
}

document.getElementById("loginBtn").addEventListener("click", function() {
    document.getElementById("loginForm").style.display = "block";
    document.getElementById("signupForm").style.display = "none";
});

document.getElementById("signupBtn").addEventListener("click", function() {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("signupForm").style.display = "block";
});
